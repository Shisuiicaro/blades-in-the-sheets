self.assetsManifest = {
  "version": "UaEBAv/a",
  "assets": [
    {
      "hash": "sha256-cjtg+V4DVskeoBfufs8WNy2K9OgeAZn7YcXDWHZPAic=",
      "url": "Pages/Index.razor.js"
    },
    {
      "hash": "sha256-k01RIT/GzPFFfxopykY52A/wNOISHoMxRGyMHIHCwb4=",
      "url": "Pages/ThemeSettings.razor.js"
    },
    {
      "hash": "sha256-QvCCFl6K/4qvQj2ljOMpW85vJwz4sJm38D3cznkAeCI=",
      "url": "UI.styles.css"
    },
    {
      "hash": "sha256-b9RSPukLvSHekr3kftcukF9Hbr4g1a5l0/cfyJ61XMA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Anchor/FluentAnchor.razor.js"
    },
    {
      "hash": "sha256-em7H1x6ijv/Ln1xS18rdjLu1JRbd3KqLfbEg9v+9Ot8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/AnchoredRegion/FluentAnchoredRegion.razor.js"
    },
    {
      "hash": "sha256-8QTQtCTbbHkwqt3rAy8ZPjez2lZ6PGmR5Il+7Q3g/rs=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Button/FluentButton.razor.js"
    },
    {
      "hash": "sha256-gVrV4WI8finQdUGG7EIZIAh2tTbFW0GF7Hl73l/1JnE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Checkbox/FluentCheckbox.razor.js"
    },
    {
      "hash": "sha256-YXK/HpBHSdAvYKGx6FxD4KNnfqJyfeRndjuw0HB6lAM=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DataGrid/FluentDataGrid.razor.js"
    },
    {
      "hash": "sha256-Ev4Kojt6pIRpgo1en7WTdMnGAI6m6iD4kfsPNHe5dzE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/DesignSystemProvider/FluentDesignTheme.razor.js"
    },
    {
      "hash": "sha256-CndcCP/YVXs68LoE68COc38ypIJenMbJyu+fR0/ZIPc=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Divider/FluentDivider.razor.js"
    },
    {
      "hash": "sha256-V4iZz/kay7SoC/eRuDViVZkhxiL1oNW1gzMAFC6k/wY=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Grid/FluentGrid.razor.js"
    },
    {
      "hash": "sha256-yf+15AR63QV4X8XvrAMxrEP5sX3Ea0tuh+Tsinb6yXU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/HorizontalScroll/FluentHorizontalScroll.razor.js"
    },
    {
      "hash": "sha256-PP/sd+/TmUOGcOlWecN29U8NiuDIEWAdn05aDunSL8Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/InputFile/FluentInputFile.razor.js"
    },
    {
      "hash": "sha256-3+jF/yOfwYyQhLujhQlSrvp3NBll+oEUF7v13pin53A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/KeyCode/FluentKeyCode.razor.js"
    },
    {
      "hash": "sha256-hXPNDHD1hTdz/sH1cD60f/ehIklf8zQAEE73UZNGtu8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Label/FluentInputLabel.razor.js"
    },
    {
      "hash": "sha256-2bhET+uXWbAao2aJyUqqscx9PObMTXmpUAkDQOQBGI8=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentAutocomplete.razor.js"
    },
    {
      "hash": "sha256-nIU5FWzn1UKAWh1+g35w3aDIn8pSmnmQV1YWZ+1eb8w=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/FluentCombobox.razor.js"
    },
    {
      "hash": "sha256-/lFyXHGb/lh02BDFUuMzwbfU+zNOdnw2s2zKSrTtW00=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/List/ListComponentBase.razor.js"
    },
    {
      "hash": "sha256-C/YKywsVlWaSpZ1PLDeRKkkkM6ki2G2gT9ny+WVuERA=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Menu/FluentMenu.razor.js"
    },
    {
      "hash": "sha256-u3HANg4jObqKg1Jso4ovjOp2lKuYeAN0+zlRIfKuHhw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/NavMenu/FluentNavMenu.razor.js"
    },
    {
      "hash": "sha256-hVi+eZ1AhYzWA2HILBTSjl5xstub4DMGzUxGJIQgjVo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overflow/FluentOverflow.razor.js"
    },
    {
      "hash": "sha256-IDySDi264SKaXFu1nL+hU2NeFhEMrX6Zv7ubUPR88VI=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Overlay/FluentOverlay.razor.js"
    },
    {
      "hash": "sha256-xlA5fSAkA6TiFUznwHP835N8kAxJ7YJ5MTizYCGeOfo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/PullToRefresh/FluentPullToRefresh.razor.js"
    },
    {
      "hash": "sha256-5Xro3i41QLeYkA4vXMC3sJ/GOerzbXq4CJRFnA+jYNE=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Search/FluentSearch.razor.js"
    },
    {
      "hash": "sha256-TAnVg0aJviMtvE8pWYaaZahF5suJcjonGCC7accq76k=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSlider.razor.js"
    },
    {
      "hash": "sha256-Em8bsrj69skLLR4IHVJ8lIJTR1EcY/U9nvcfn9t1rzo=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Slider/FluentSliderLabel.razor.js"
    },
    {
      "hash": "sha256-rBxLYd0QGHwfD9IZljh74Lf+ZC+zqoRLqwikRKcRgpg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/SortableList/FluentSortableList.razor.js"
    },
    {
      "hash": "sha256-kExJSsKpmByqtTJ/TOwptCU5yawR+13aqkZxoVN+a1A=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Splitter/FluentMultiSplitter.razor.js"
    },
    {
      "hash": "sha256-Kh0YI9vhH0m+YJJvQVdOvtm0zuIIGEdRv3aH6iv7Gcg=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tabs/FluentTab.razor.js"
    },
    {
      "hash": "sha256-EnvcMggAdstebmtcZrEOhDW5p/e0dFj2ZywJtuMypIw=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/TextField/FluentTextField.razor.js"
    },
    {
      "hash": "sha256-pWY0aUTl5SagZBQwX/+DOHxke3fHSPoZdTQXbRQSFTU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Components/Tooltip/FluentTooltip.razor.js"
    },
    {
      "hash": "sha256-s8i9htPaAt7ZBCd4Nd0wqrNPZB5+37bPZH72pf5wd9o=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.dwk6czdzfo.bundle.scp.css"
    },
    {
      "hash": "sha256-/LPTy2KpNBBYdj9b6lNMDILfmbdqo+FWKCFS6WQd0mU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js"
    },
    {
      "hash": "sha256-gD29yOMICDIiYM16Dl8m2EwS2lyds8DoFkgTy29qko4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.LEGAL.txt"
    },
    {
      "hash": "sha256-4SNdvLM7SDhaju7Ir+uYFq6/+6PwZqn7sQPCIe+nI0g=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/Microsoft.FluentUI.AspNetCore.Components.lib.module.js.map"
    },
    {
      "hash": "sha256-2wyFQ9++b6uYwv3gv265xtRV2OWnPQMN68NpUHffScU=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/css/reboot.css"
    },
    {
      "hash": "sha256-L9w4Nw5htE5XBWcy0I11eRfWwkTxtN8VSJWnitKu30Q=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/initializersLoader.webview.js"
    },
    {
      "hash": "sha256-kX+9ky61TMxar94Z7+S8myontpvgH4571DVehjxVvM4=",
      "url": "_content/Microsoft.FluentUI.AspNetCore.Components/js/loading-theme.js"
    },
    {
      "hash": "sha256-rN9ebccf1yzi+bWyyip51JJuAKONWUHDBKWnKUpDWAA=",
      "url": "_content/Toolbelt.Blazor.GetProperty.Script/Toolbelt.Blazor.GetProperty.Script.lib.module.js"
    },
    {
      "hash": "sha256-LdIFvKzEm8HagX4b1VAPR7Uo/BEliBDtCeCgeXTUa9s=",
      "url": "_content/Toolbelt.Blazor.HotKeys2/script.min.js"
    },
    {
      "hash": "sha256-9j4iJEwca5bjLN0jWGV0/0hXXIig9zItgbG2WbVWRE0=",
      "url": "_framework/Blazored.LocalStorage.aspas9o5sr.wasm"
    },
    {
      "hash": "sha256-KI0R4sbXO6WpEnDR8y3ZACSz8l0JZ5+Th/E9wGFs430=",
      "url": "_framework/FluentAssertions.sjthra2ptd.wasm"
    },
    {
      "hash": "sha256-gw5JhyVA+lyWsgfz+sEIeV4Xw5ZvIqFJdv/d/sEPV1o=",
      "url": "_framework/Microsoft.AspNetCore.Components.958tjsk8qu.wasm"
    },
    {
      "hash": "sha256-XXXGFcM+xxWNTlBns9PPuvrsSQzrGnHFJ+dS466iHUk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.vhae2zrsel.wasm"
    },
    {
      "hash": "sha256-8xNNgm8SYfD7ShAM5lUqujOtWMs/2CpiuMFi/dGPymM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.l23etm5d7f.wasm"
    },
    {
      "hash": "sha256-IIcyKKCtpjmG1LFF8qtNDVqV8eJ3w3Wsmw8BGR9AQx8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.w82mof53lb.wasm"
    },
    {
      "hash": "sha256-vBmcUxh1//BNHprMjqOzCfaS6a8kdlHlG1+IB+sUZac=",
      "url": "_framework/Microsoft.CSharp.ssjy9ipv3q.wasm"
    },
    {
      "hash": "sha256-+AOBWABucqvIbXvM5o13N9MMw86pSdZXhJK0nhizA64=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.crj00u2plu.wasm"
    },
    {
      "hash": "sha256-966vLTPPdM/VT3Us1DmiVRZ01ty1KKep+/sMLMGfkto=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.9oiuvi1mc3.wasm"
    },
    {
      "hash": "sha256-GEC2SjmtyS3vzBqlQUxSU4AW6gM5Tu4eipcK092PQGg=",
      "url": "_framework/Microsoft.Extensions.Configuration.sv70kdrgo7.wasm"
    },
    {
      "hash": "sha256-2HJ9N8AFtg9V92z4l+p5niLe2LalYTonUJu/vXBlT2Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.kdjvr1qzir.wasm"
    },
    {
      "hash": "sha256-Dld5NGeXnx7HHX1bbmTE2swyRFRwS2K5z4EujQ7P/tU=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.i4pfk2iy2o.wasm"
    },
    {
      "hash": "sha256-ZDzGMj+t5VWQFakJP9dYMQFIvHJNrNjpAx/knKrvprI=",
      "url": "_framework/Microsoft.Extensions.Logging.0nqf7im5hq.wasm"
    },
    {
      "hash": "sha256-EiXPRgRn4F44pHTPJVUPyzL86kn89XefiP5NdmICxqg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.utq95k44ap.wasm"
    },
    {
      "hash": "sha256-7RJ/wKs4xgM84vkiCdm82ynNxCIlcGRZ1nAaYcVhNtw=",
      "url": "_framework/Microsoft.Extensions.Options.9l7mrik2mr.wasm"
    },
    {
      "hash": "sha256-m4uKnWSZP3dtCWsXIeS3Pm/+yVoSU391HrlGUZo9QWM=",
      "url": "_framework/Microsoft.Extensions.Primitives.zatx90lqto.wasm"
    },
    {
      "hash": "sha256-oQSVX+j5cwTWj0OfEEE2DUJNAYxItVk7mUTNcVJttDs=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.Icons.bt83wjemql.wasm"
    },
    {
      "hash": "sha256-GIKSgfHrWBUnQtBj+XbYOq8EbZlufiZHy41i7USi9wM=",
      "url": "_framework/Microsoft.FluentUI.AspNetCore.Components.o00w2q998x.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-njULh9eeKEWmYORJaFSJTS5lZpWQ2l4OAOw+d8h7XFg=",
      "url": "_framework/Microsoft.JSInterop.ykf6i1s2y1.wasm"
    },
    {
      "hash": "sha256-fS3tTlfdlD7cgVQEIfBf/4Xm9KPisQ1J5X5SYIhhedk=",
      "url": "_framework/Models.nz4pph1hym.wasm"
    },
    {
      "hash": "sha256-dofphMubV0l1oNih+xiZv2dhrTu61+bcw3RIclbVhD0=",
      "url": "_framework/Newtonsoft.Json.q76kvjkd82.wasm"
    },
    {
      "hash": "sha256-krq5YMLGeVPSVHlglSzO0bRWOB5XAU8LcfnOIzfoUZQ=",
      "url": "_framework/Persistence.yffx1mohnq.wasm"
    },
    {
      "hash": "sha256-X3sbJIc77a+1oRkHOxv/hTtBmjB7v/KoLVvtkRNlA1g=",
      "url": "_framework/System.Collections.1841l1miry.wasm"
    },
    {
      "hash": "sha256-0NRdBbfpOSyOqIEyntB0Pai8/pK1qMuPkwMGaZ8i5Nw=",
      "url": "_framework/System.Collections.Concurrent.0cs3dzekes.wasm"
    },
    {
      "hash": "sha256-5rp4Q+MzcPfZj2e4RbsdME/cgWvU2qT47y2z0eUcjUY=",
      "url": "_framework/System.Collections.Immutable.ef7me6ppoj.wasm"
    },
    {
      "hash": "sha256-GmGIPWIbtYUMW4PLSLun6PZdqmmsKQ1RTNvLz2a0/+Y=",
      "url": "_framework/System.Collections.NonGeneric.613naqs5uu.wasm"
    },
    {
      "hash": "sha256-UzrLZn1y45CYrIqRnCoJFpEdP76BcrWsfN+6uRbVB1Q=",
      "url": "_framework/System.Collections.Specialized.tsy25hejgz.wasm"
    },
    {
      "hash": "sha256-vzXrHtQnQ3ttbtS7N479mXBohi3ncJRtWKTnlyvJUOE=",
      "url": "_framework/System.ComponentModel.Primitives.3zx72rspps.wasm"
    },
    {
      "hash": "sha256-GL9qm6YQFDzooqyAYR+sQ97UfXIuxUqBm6JKV9m1knw=",
      "url": "_framework/System.ComponentModel.TypeConverter.c7mygjylla.wasm"
    },
    {
      "hash": "sha256-tdpEpypSSZ90GwFrnBPnLoPcDoTHbwRvsvCSFFHpyDA=",
      "url": "_framework/System.ComponentModel.h5zzyr9cai.wasm"
    },
    {
      "hash": "sha256-CUypzd26l6YQjr1s+vQUWe1QvPJ//mx25IFZh0bYN28=",
      "url": "_framework/System.Configuration.ConfigurationManager.huswae3maj.wasm"
    },
    {
      "hash": "sha256-n7XWpvwvWP7z9eUGPhz269b5HxlOhXbsMTsQwrL3P98=",
      "url": "_framework/System.Console.hksbpr62ya.wasm"
    },
    {
      "hash": "sha256-FqpCia4QvveEEbg8mucP7EJgswWi28YU5YtFkryEkgo=",
      "url": "_framework/System.Data.Common.2qg1nluibo.wasm"
    },
    {
      "hash": "sha256-l70HbBee3+2FMS2hjsib/Ounr1lcVas8RrcDAdUTIQw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.tr45r88ods.wasm"
    },
    {
      "hash": "sha256-9fWWZ91OS9GdNarl3LL7naAShuVTCkrUzgpgofRBKsM=",
      "url": "_framework/System.Diagnostics.StackTrace.f312kdrgyo.wasm"
    },
    {
      "hash": "sha256-I5ODUwjdHS0WTH+DUcOMGD9xswca8z34NKgw6bxmZlk=",
      "url": "_framework/System.Diagnostics.TraceSource.jc2xxyc39r.wasm"
    },
    {
      "hash": "sha256-zcqU4bLpKQ2pq4uHcy/xso1tunN7P/fStG6uOZdOlqY=",
      "url": "_framework/System.Drawing.30nntpi0qg.wasm"
    },
    {
      "hash": "sha256-R1ubmkbB6f95OWE9bkvb3aMuZxyg6QUJmrKxzC/6O24=",
      "url": "_framework/System.Drawing.Primitives.notg18u3ut.wasm"
    },
    {
      "hash": "sha256-2e/KAkg2pvhmQTu1q0x2OfsNHMoW9IBU+JcqqXvXu8A=",
      "url": "_framework/System.IO.Pipelines.xec0hsdhj9.wasm"
    },
    {
      "hash": "sha256-faHqbXgHrPSYNUcrILRO5CeYiDvwrti0Syrf7+ruXZ4=",
      "url": "_framework/System.Linq.Expressions.rurm4tlb9e.wasm"
    },
    {
      "hash": "sha256-eg1ToEYImY6e7L+RoULDFcxIBTl+daRGwWrQFJ1RwB0=",
      "url": "_framework/System.Linq.a741b39njs.wasm"
    },
    {
      "hash": "sha256-EyPp7u+BGJoOlL51nLvf2WzxQWshHYkPSw9xR36UVMw=",
      "url": "_framework/System.Memory.zwjl32qkjg.wasm"
    },
    {
      "hash": "sha256-sAZNZrH2rlmFN/M7kxtAnR5L2LlaMX1LBZVuhGiXdps=",
      "url": "_framework/System.Net.Http.ch2bsbbbee.wasm"
    },
    {
      "hash": "sha256-pSckz//Cm4XEjiXuf4+irhQtEW1T9jxu6etVQxu6o5o=",
      "url": "_framework/System.Net.Primitives.v3l2hsqrg5.wasm"
    },
    {
      "hash": "sha256-2SwdhciLir25epmpTgxjWbVsQv+69+WC9qvd+KS2rHc=",
      "url": "_framework/System.Net.WebClient.zxab3t1t13.wasm"
    },
    {
      "hash": "sha256-BxLM1C+riINyXq3NPWG40R3lOfkh84fgudhe6G0QFfs=",
      "url": "_framework/System.ObjectModel.zpy9a0bskr.wasm"
    },
    {
      "hash": "sha256-Iw4urC8NW8VehsRyKmSCQtjyhok5RalQccPUknuMGFY=",
      "url": "_framework/System.Private.CoreLib.7bhmx79l38.wasm"
    },
    {
      "hash": "sha256-0M9fBEJxfzP58MPnAvWlq2yPmWX6LSxgpUVhDrp1pjU=",
      "url": "_framework/System.Private.DataContractSerialization.0g3jsbb53s.wasm"
    },
    {
      "hash": "sha256-8KX5MA+MGgb0+ONZD6AXqW6ENBvsEReV0jMdQBLD6Uo=",
      "url": "_framework/System.Private.Uri.k7c1eazwpd.wasm"
    },
    {
      "hash": "sha256-62LnYmHkX7qmDQzrHZ6V1PlBg6J28jS2jOO1aXzy+RA=",
      "url": "_framework/System.Private.Xml.1tgo28xzbw.wasm"
    },
    {
      "hash": "sha256-oAaNlyQdRgJmfpkRkPkbk9onRsHvnLt0+YlxBjUEx+0=",
      "url": "_framework/System.Private.Xml.Linq.4zjqrhg59k.wasm"
    },
    {
      "hash": "sha256-28LLk/yw1oWfa8IDh4aqYeWxvQs4HWWFscua1rmCEsI=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.h5m8f3k671.wasm"
    },
    {
      "hash": "sha256-jInTKCLV9uhZFZtM8nhAQXv10M5o9PpJO+I7GS40j2c=",
      "url": "_framework/System.Reflection.Emit.Lightweight.4mngibteh2.wasm"
    },
    {
      "hash": "sha256-5xC6Wp31dYBKSHnmvb7Jb37NP8Y9rELxQvkaPbCwFvw=",
      "url": "_framework/System.Reflection.Primitives.bjj4tmk12m.wasm"
    },
    {
      "hash": "sha256-kh+i0N9XSKZMfGG0bTMs8nxQloLTTgkk7CuF2ZC4nGU=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.y0r344ylzs.wasm"
    },
    {
      "hash": "sha256-qZRzDzzosJhf/YwBwamdSGXGMOaxCPiAo1QrAKwjXFQ=",
      "url": "_framework/System.Runtime.InteropServices.pkgzm8qz7c.wasm"
    },
    {
      "hash": "sha256-JFZDgM0uUq8lnpUU4Ldjh6/KXc5WC/eh1GdTzCT8+MU=",
      "url": "_framework/System.Runtime.Numerics.s2c05hlrpq.wasm"
    },
    {
      "hash": "sha256-cqp9eWazk+L9b1DluAcgx+bUD95U9sbbjaadx1szUhY=",
      "url": "_framework/System.Runtime.Serialization.Formatters.alxijm5uxn.wasm"
    },
    {
      "hash": "sha256-ua2WXtd9anwTniIsAAWQ1jcndr57Vh9Mh9yQgm2PTiU=",
      "url": "_framework/System.Runtime.Serialization.Primitives.94mb1ux2og.wasm"
    },
    {
      "hash": "sha256-F7LK2HWim4xJyhfYL5RPVVXKp02Yb+VCgacGExLmnns=",
      "url": "_framework/System.Runtime.Serialization.Xml.rzhwr5mgjm.wasm"
    },
    {
      "hash": "sha256-BdxivlarRN0NhHmWvbdnufI0dMyNUIzF1sSL1tCV7v0=",
      "url": "_framework/System.Runtime.prm32xivxx.wasm"
    },
    {
      "hash": "sha256-AIezFXhQytgge81EAESC8BDjnQCCSZTNWoSvG3m6q6M=",
      "url": "_framework/System.Security.Cryptography.4r7zh9sdc3.wasm"
    },
    {
      "hash": "sha256-A0+dH38KcJd6RU6/cC9JWpkICkMQTow4tbf6GHHcipk=",
      "url": "_framework/System.Security.Cryptography.ProtectedData.f1t8awcip5.wasm"
    },
    {
      "hash": "sha256-LlYX5HbDxa+g3PHrtMO6lABCowoJ7BnxHoFp2MZ+tm4=",
      "url": "_framework/System.Text.Encoding.Extensions.u9vy7ox4r6.wasm"
    },
    {
      "hash": "sha256-gUmRPPQVZqkjN2NscwUqpvSM0t6HbBxicMvnE9bvMNM=",
      "url": "_framework/System.Text.Encodings.Web.xczmlyvsr8.wasm"
    },
    {
      "hash": "sha256-vkDPPE+BHdYwYEAOC0XCqa4ETFiGyhR+foAZTaTTUNM=",
      "url": "_framework/System.Text.Json.u061skkbul.wasm"
    },
    {
      "hash": "sha256-sM0r9qJ7aXw0NonZOcXSWMa97Kstt5bYAM1stPJRYQg=",
      "url": "_framework/System.Text.RegularExpressions.c188j04ft8.wasm"
    },
    {
      "hash": "sha256-ijhQ5jLHeySNQ3s5w1ayexQiFeBVwTbkEWI4AT0+Zvc=",
      "url": "_framework/System.Threading.yhzbr5l7yr.wasm"
    },
    {
      "hash": "sha256-R9FktnaduRAvMaZfcRZAXAs4UUQFRWQ+IzNgO/1vj8I=",
      "url": "_framework/System.Xml.Linq.no17d80mwx.wasm"
    },
    {
      "hash": "sha256-LukDxRKJe1UQxxqmRgIiDOCutGtkznvBYem0cKj+xAc=",
      "url": "_framework/System.Xml.ReaderWriter.u4kx5wue0z.wasm"
    },
    {
      "hash": "sha256-hmJG3URfrJa13okNkDgzAwFZN17rrWqw+vAQ5VJoRZ0=",
      "url": "_framework/System.Xml.XDocument.ier3sxb28o.wasm"
    },
    {
      "hash": "sha256-KFBVzrFKmfs1RJqCZDiUNsr8ddVdseQg2vjoZryxt6g=",
      "url": "_framework/System.Xml.XmlSerializer.0akydu5sua.wasm"
    },
    {
      "hash": "sha256-JTFuCK158shXIWK3NjdzwK5OZag1jcRJzsH8H5Gd6OA=",
      "url": "_framework/System.pndwwxah3a.wasm"
    },
    {
      "hash": "sha256-NvfSCDkdamHapL2jeOgKVWlJOYFLNoDzRA8/D9JmvVU=",
      "url": "_framework/Toolbelt.Blazor.HotKeys2.yubrgxeypw.wasm"
    },
    {
      "hash": "sha256-Jn8W8x0X9pYJ9zpzFY9mgzFEqPPt/Zq7ILBcZdolFso=",
      "url": "_framework/UI.e29xvdslhq.wasm"
    },
    {
      "hash": "sha256-i0LgTUczdTyVzfdoorA59WsaWRJgFPLSvjcK3kgqWsw=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-lIFBSyH5fOmCyz9NzfVceXU09qRLS0mn0JZG0tuYWBo=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-/cJLAdGpDfToZ8kioUO1+JNfejdF+I51TQ3GcsWDk04=",
      "url": "_framework/dotnet.native.fdqu42huve.js"
    },
    {
      "hash": "sha256-O9q6NwtrgVj6aUyBrXj9CX7HbW1ms1uP6VAOw5MVNkk=",
      "url": "_framework/dotnet.native.hlkuqyofs0.wasm"
    },
    {
      "hash": "sha256-gypqZnsxxUh4y4EJmawvOCaX4hoTaesVGwIgWXwZcNw=",
      "url": "_framework/dotnet.runtime.rubq0v1yiy.js"
    },
    {
      "hash": "sha256-LwF9AKZyVJdYO+F0aDHNvgEUZ+tNhNjNmAoaUmOsc+g=",
      "url": "_framework/netstandard.b9u0g6we9s.wasm"
    },
    {
      "hash": "sha256-I0GanVsE4tKDf/vX5H+ohgCyslhvRIPf8OyuxGggd44=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css/open-iconic/FONT-LICENSE"
    },
    {
      "hash": "sha256-s/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css/open-iconic/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css/open-iconic/README.md"
    },
    {
      "hash": "sha256-BJ/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css/open-iconic/font/css/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh/chSkSvQpc=",
      "url": "css/open-iconic/font/fonts/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv/U1xl/9D3ehyU69JE+FvAcu5HQ+/a0=",
      "url": "css/open-iconic/font/fonts/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css/open-iconic/font/fonts/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css/open-iconic/font/fonts/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ/v/QzXlejRDwUNdZIofI=",
      "url": "css/open-iconic/font/fonts/open-iconic.woff"
    },
    {
      "hash": "sha256-5XgqLa3pTOVkRieSrZyG258m8YzfpdKd4/OC/Npy0OQ=",
      "url": "data/blades-in-the-dark.json"
    },
    {
      "hash": "sha256-caFgpKU6XHS2Aajwz0Nb8FM2C0zGLrS+a8aFalXKgwo=",
      "url": "data/demo-character.json"
    },
    {
      "hash": "sha256-17G4wJYOcGsdo1S9UujWBVzwUZPO85YcldSiXqV5bdQ=",
      "url": "data/français-blades-in-the-dark.json"
    },
    {
      "hash": "sha256-0Jx8C6y3SRq6sfLKEugiA4vwC7ikVZnVeDJ9ri/e/yU=",
      "url": "data/game-settings-schema.json"
    },
    {
      "hash": "sha256-0zDh5z0gDesMxXbK0kRU9aEBIGb9FYLqf15z0i64Yos=",
      "url": "data/games.json"
    },
    {
      "hash": "sha256-WPohlQI1rB7kH+/7mcVibSBVNie1UNI2oMg8Fmrm3xI=",
      "url": "data/scum-and-villainy.json"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-TQdSzRqxBK3kRj5lCW8T8H7dDsHoiD9WF++ijDJjMKk=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-73fH3ihnUgzvOwjyOyy8q3HzZaKOz6733WLwIkp7Gls=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-PTlmOCFHBU4qK8E23TNsWgq90XPtI5jiTHhfL6ZGLpw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fPY7NPNxjWtf3xihK+O361nL8+1zG1S5P/33wqguUTs=",
      "url": "manifest.webmanifest"
    }
  ]
};
